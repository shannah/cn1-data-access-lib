/*
 * Copyright (c) 2012, Codename One and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.  Codename One designates this
 * particular file as subject to the "Classpath" exception as provided
 * by Oracle in the LICENSE file that accompanied this code.
 *  
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 * 
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 * 
 * Please contact Codename One through http://www.codenameone.com/ if you 
 * need additional information or have any questions.
 */

package com.codename1.ui.layouts;

import com.codename1.ui.Component;
import com.codename1.ui.Container;
import com.codename1.ui.Display;
import com.codename1.ui.List;
import com.codename1.ui.geom.Dimension;
import com.codename1.ui.plaf.Style;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Allows placing components based on guides and constraints in a similar way
 * to group layout. Unlike group layout this layout was designed with Codename One
 * in mind and its GUI builder.
 * <p>Unlike most other layout managers this layout manager is designed for usage
 * in full screen and not designed for nesting although it can be nested.
 *
 * @author Shai Almog
 */
class GuidedLayout extends Layout {
    
    private final ArrayList<Attachments> att = new ArrayList<Attachments>();
    
    private Attachments getAttachment(Component cmp) {
        for(Attachments a : att) {
            if(a.destination == cmp) {
                return a;
            }
        }
        Attachments a = new Attachments();
        a.destination = cmp;
        att.add(a);
        return a;
    }
    
    public void sameWidth(Component... cmps) {
        Attachments[] arr = new Attachments[cmps.length];
        for(int iter = 0 ; iter < cmps.length ; iter++) {
            arr[iter] = getAttachment(cmps[iter]);
            arr[iter].sameWidth = arr;
        }
    }

    public void sameHeight(Component... cmps) {
        Attachments[] arr = new Attachments[cmps.length];
        for(int iter = 0 ; iter < cmps.length ; iter++) {
            arr[iter] = getAttachment(cmps[iter]);
            arr[iter].sameHeight = arr;
        }
    }
    
    public void growHorizontal(Component... cmps) {
        for(Component c : cmps) {
            getAttachment(c).growHorizontal = true;
        }
    }
    
    public void growVertical(Component... cmps) {
        for(Component c : cmps) {
            getAttachment(c).growVertical = true;
        }
    }
    
    public void attachLeft(Component cmp) {
        getAttachment(cmp).leftEdge = true;
    }
    
    public void attachRight(Component cmp) {
        getAttachment(cmp).rightEdge = true;
    }

    public void attachBottom(Component cmp) {
        getAttachment(cmp).bottomEdge = true;
    }

    public void attachTop(Component cmp) {
        getAttachment(cmp).topEdge = true;
    }
    
    public void attachLeftTo(Component to, Component source) {
        getAttachment(to).left = getAttachment(source);
    }

    public void attachRightTo(Component to, Component source) {
        getAttachment(to).right = getAttachment(source);
    }

    public void attachTopTo(Component to, Component source) {
        getAttachment(to).top = getAttachment(source);
    }

    public void attachBottomTo(Component to, Component source) {
        getAttachment(to).bottom = getAttachment(source);
    }
    
    public void alignLeft(Component... cmps) {
        
    }
    
    public void alignRight(Component... cmps) {
        
    }
    
    public void alignCenter(Component... cmps) {
        
    }
    
    public void attachHorizontalCenter(Component cmp) {
        getAttachment(cmp).hCenterAttach = true;
    }
    
    public void attachVerticalCenter(Component cmp) {
        getAttachment(cmp).vCenterAttach = true;
    }
    
    /**
     * @inheritDoc
     */
    @Override
    public void layoutContainer(Container parent) {
        Style parentStyle = parent.getStyle();
        int startX = parentStyle.getPadding(Component.LEFT);
        int startY = parentStyle.getPadding(Component.TOP);
        int parentWidth = parent.getWidth() - startX - parentStyle.getPadding(Component.RIGHT);
        int parentHeight = parent.getHeight() - startY - parentStyle.getPadding(Component.BOTTOM);
                
        // remove unused attachments
        for(int iter = 0 ; iter < att.size() ; iter++) {
            Attachments a = att.get(iter);
            if(a.destination.getParent() != parent) {
                att.remove(iter);
                iter--;
            }
            
        }
        
        // iterate over attachments for first stage of layout
        for(Attachments a : att) {
            a.reset();
            a.initHardConstraint(parent, startX, startY, parentWidth, parentHeight);
        }

        for(Attachments a : att) {
            a.initKnownSizes(parent, startX, startY, parentWidth, parentHeight);
        }

        for(Attachments a : att) {
            a.layoutAttachments(parentWidth, parentHeight);
        }

        // final loop, apply the layout constraints to the components
        for(Attachments a : att) {
            a.applyLayout();
        }
    }

    /**
     * @inheritDoc
     */
    @Override
    public Dimension getPreferredSize(Container parent) {
        Display d = Display.getInstance();
        return new Dimension(d.getDisplayWidth(), d.getDisplayHeight());
    }

    /**
     * @inheritDoc
     */
    @Override
    public boolean obscuresPotential(Container parent) {
        return super.obscuresPotential(parent); //To change body of generated methods, choose Tools | Templates.
    }

    /**
     * @inheritDoc
     */
    @Override
    public boolean isConstraintTracking() {
        return false;
    }

    /**
     * @inheritDoc
     */
    @Override
    public boolean isOverlapSupported() {
        return false;
    }

    /**
     * @inheritDoc
     */
    @Override
    public Object getComponentConstraint(Component comp) {
        return null;
    }

    /**
     * @inheritDoc
     */
    @Override
    public void removeLayoutComponent(Component comp) {
        //att.remove(getAttachment(comp));
        super.removeLayoutComponent(comp); 
    }

    /**
     * @inheritDoc
     */
    @Override
    public void addLayoutComponent(Object value, Component comp, Container c) {
        //getAttachment(comp);
        super.addLayoutComponent(value, comp, c); 
    }
    
    /**
     * Defines the layout constraint for the guided layout
     */
    static class Attachments {
        Component destination;
        
        // component attached to this component on the left, right top and bottom sides
        Attachments left;
        Attachments right;
        Attachments top;
        Attachments bottom;
        boolean leftEdge;
        boolean rightEdge;
        boolean topEdge;
        boolean bottomEdge;

        boolean hCenterAttach;
        boolean vCenterAttach;

        Attachments[] sameWidth;
        Attachments[] sameHeight;
        Attachments[] align;
        int alignDirection;        
        boolean growHorizontal;
        boolean growVertical;
        
        private int width;
        private int height;
        private int x1;
        private int y1;
        private int x2;
        private int y2;
        
        private int marginLeft;
        private int marginRight;
        private int marginTop;
        private int marginBottom;
        
        public void reset() {
            x1 = Integer.MIN_VALUE;
            x2 = Integer.MIN_VALUE;
            y1 = Integer.MIN_VALUE;
            y2 = Integer.MIN_VALUE;
            width = Integer.MIN_VALUE;
            height = Integer.MIN_VALUE;
            Style s = destination.getStyle();
            marginLeft = s.getMargin(Component.LEFT);
            marginRight = s.getMargin(Component.RIGHT);
            marginTop = s.getMargin(Component.TOP);
            marginBottom = s.getMargin(Component.BOTTOM);
        }
        
        public void initHardConstraint(Container parent, int startX, int startY, int width, int height) {
            if(leftEdge) {
                x1 = startX + marginLeft;
            }
            if(rightEdge) {
                x2 = startX + width - marginRight;
            }
            if(topEdge) {
                y1 = startY + marginTop;
            }
            if(bottomEdge) {
                y2 = startY + height - marginBottom;
            }    
        }
        
        private void initSameWidth() {
            int max = Integer.MIN_VALUE;
            for(Attachments a : sameWidth) {
                max = Math.max(a.destination.getPreferredW(), max);
            }
            
            for(Attachments a : sameWidth) {
                a.width = max;
            }
        }

        private void initSameHeight() {
            int max = Integer.MIN_VALUE;
            for(Attachments a : sameHeight) {
                max = Math.max(a.destination.getPreferredH(), max);
            }
            
            for(Attachments a : sameHeight) {
                a.height = max;
            }
        }
        
        public void initKnownSizes(Container parent, int startX, int startY, int parentWidth, int parentHeight) {
            // takes up full width
            if(leftEdge && rightEdge) {
                width = parentWidth;
            } else {
                if(!growHorizontal) {
                    if(sameWidth == null) {
                        width = destination.getPreferredW();
                    } else {
                        if(width == Integer.MIN_VALUE) {
                            initSameWidth();
                        }
                    }
                }
            }
            // takes up full height 
            if(topEdge && bottomEdge) {
                height = parentHeight;
            } else {
                if(!growVertical) {
                    if(sameHeight == null) {
                        height = destination.getPreferredH();
                    } else {
                        if(height == Integer.MIN_VALUE) {
                            initSameHeight();
                        }
                    }
                }
            }
        }
        
        private int getX2() {
            if(x2 != Integer.MIN_VALUE) {
                return x2;
            }
            if(x1 != Integer.MIN_VALUE && width != Integer.MIN_VALUE) {
                x2 = x1 + width;
                return x2;
            }
            return Integer.MIN_VALUE;
        }

        private int getX1() {
            if(x1 != Integer.MIN_VALUE) {
                return x1;
            }
            if(x2 != Integer.MIN_VALUE && width != Integer.MIN_VALUE) {
                x1 = x2 - width;
                return x1;
            }
            return Integer.MIN_VALUE;
        }
        
        private int getY2() {
            if(y2 != Integer.MIN_VALUE) {
                return y2;
            }
            if(y1 != Integer.MIN_VALUE && height != Integer.MIN_VALUE) {
                y2 = y1 + height;
                return y2;
            }
            return Integer.MIN_VALUE;
        }

        private int getY1() {
            if(y1 != Integer.MIN_VALUE) {
                return y1;
            }
            if(y2 != Integer.MIN_VALUE && height != Integer.MIN_VALUE) {
                y1 = y2 - height;
                return y1;
            }
            return Integer.MIN_VALUE;
        }
        
        public void layoutAttachments(int parentWidth, int parentHeight) {
            if(hCenterAttach) {
                if(width == Integer.MIN_VALUE) {
                    width = destination.getPreferredW();
                }
                x1 = parentWidth / 2 - width / 2;
                x2 = x1 + width;
            }
            
            if(vCenterAttach) {
                if(height == Integer.MIN_VALUE) {
                    height = destination.getPreferredH();
                }
                y1 = parentHeight / 2 - height / 2;
                y2 = y1 + height;
            }

            if(left != null && left.x1 == Integer.MIN_VALUE) {
                int x1Pos = getX1();
                if(x1Pos != Integer.MIN_VALUE) {
                    left.x2 = x1Pos - marginRight - left.marginLeft;
                }
            }
            if(right != null && right.x1 == Integer.MIN_VALUE) {
                int x2Pos = getX2();
                if(x2Pos != Integer.MIN_VALUE) {
                    right.x1 = x2Pos + marginRight + right.marginLeft;
                }
            }
            if(top != null && top.y1 == Integer.MIN_VALUE) {
                int y1Pos = getY1();
                if(y1Pos != Integer.MIN_VALUE) {
                    top.y2 = y1Pos - marginTop - top.marginBottom;
                }
            }
            if(bottom != null && bottom.y1 == Integer.MIN_VALUE) {
                int y2Pos = getY2();
                if(y2Pos != Integer.MIN_VALUE) {
                    bottom.y1 = y2Pos + marginBottom + bottom.marginTop;
                }
            }
        }
        
        public void applyLayout() {
            if(x1 == Integer.MIN_VALUE) {
                if(width != Integer.MIN_VALUE) {
                    if(x2 != Integer.MIN_VALUE) {
                        x1 = x2 - width;
                    } else {
                        x2 = x1 + width;
                    }
                } else {
                    if(x2 != Integer.MIN_VALUE) {
                        width = destination.getPreferredW();
                        x1 = x2 - width;
                    } 
                }
            } else {
                if(x2 == Integer.MIN_VALUE) {
                    if(width == Integer.MIN_VALUE) {
                        width = destination.getPreferredW();
                    }
                    x2 = x1 + width;
                }
            }

            if(y1 == Integer.MIN_VALUE) {
                if(height != Integer.MIN_VALUE) {
                    if(y2 != Integer.MIN_VALUE) {
                        y1 = y2 - height;
                    } else {
                        y1 = 0;
                        y2 += height;
                    }
                } else {
                    if(y2 == Integer.MIN_VALUE) {
                        if(height == Integer.MIN_VALUE) {
                            height = destination.getPreferredH();
                        }
                        y1 = 0;
                        y2 = height;
                    } 
                }
            } else {
                if(y2 == Integer.MIN_VALUE) {
                    if(height == Integer.MIN_VALUE) {
                        throw new RuntimeException("Missing secondary vertical constraint on " + destination);
                    }
                    y2 = y1 + height;
                }
            }

            
            if(x1 == Integer.MIN_VALUE || y1 == Integer.MIN_VALUE) {
                throw new RuntimeException("Missing constraint on " + destination);
            }
            
            if(width == Integer.MIN_VALUE) {
                width = x2 - x1;
            }
            if(height == Integer.MIN_VALUE) {
                height = y2 - y1;
            }
            
            destination.setWidth(width);
            destination.setHeight(height);
            destination.setX(x1);
            destination.setY(y1);
        }
    }
}
